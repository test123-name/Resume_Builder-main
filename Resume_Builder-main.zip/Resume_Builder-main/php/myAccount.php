<?php
session_start();
include_once('db_connection.php'); // عدل المسار حسب مكان الملفات
include_once('session.php'); // إذا موجود

// تحقق من وجود معرف المستخدم في الجلسة
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];

// جلب بيانات المستخدم من قاعدة البيانات
$stmt = $conn->prepare("SELECT * FROM resume_users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("User Account Not Found");
}

$user = $result->fetch_assoc();

// البيانات الشخصية
$fullName = htmlspecialchars($user['user_name']);
$email = htmlspecialchars($user['email']);
$avatarLetter = mb_substr($fullName, 0, 1, "UTF-8");

// جلب السير الذاتية للمستخدم
$stmt2 = $conn->prepare("SELECT * FROM resume_data WHERE user_id = ? ORDER BY id DESC");
$stmt2->bind_param("i", $userId);
$stmt2->execute();
$resumeResult = $stmt2->get_result();
$resumes = $resumeResult->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$stmt2->close();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <title>صفحتي الشخصية | Tawzeef</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #1a1a2e; color: #e0e0e0; direction: rtl; }
        .profile-avatar { width: 80px; height: 80px; background-color: #4a148c; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 36px; font-weight: bold; margin-bottom: 10px; color: #fff; }
        .sidebar { background-color: #6a0572; padding: 20px; border-radius: 10px; width: 300px; }
        .container-flex { display: flex; gap: 20px; padding: 20px; }
        .resume-table { background-color: #2a2a4a; border-radius: 10px; padding: 15px; flex-grow: 1; }
        a { color: #e0e0e0; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container-flex">
        <div class="sidebar text-center">
            <div class="profile-avatar"><?= $avatarLetter ?></div>
            <h3><?= $fullName ?></h3>
            <p><?= $email ?></p>
            <a href="logoutCode.php" class="btn btn-danger my-2">تسجيل الخروج</a>
            <a href="resumeForm.php" class="btn btn-success my-2">إضافة سيرة ذاتية جديدة</a>
        </div>
        <div class="resume-table">
            <h4>السير الذاتية الخاصة بي</h4>
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th>رقم السيرة</th>
                        <th>الاسم</th>
                        <th>البريد الإلكتروني</th>
                        <th>الهاتف</th>
                        <th>العنوان</th>
                        <th>عرض</th>
                        <th>تعديل</th>
                        <th>حذف</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($resumes as $resume): ?>
                    <tr>
                        <td><?= $resume['id'] ?></td>
                        <td><?= htmlspecialchars($resume['name']) ?></td>
                        <td><?= htmlspecialchars($resume['email']) ?></td>
                        <td><?= htmlspecialchars($resume['phone']) ?></td>
                        <td><?= htmlspecialchars($resume['title']) ?></td>
                        <td><a href="resumeTemplate.php?id=<?= $resume['id'] ?>" target="_blank">عرض</a></td>
                        <td><a href="resumeForm.php?id=<?= $resume['id'] ?>" target="_blank">تعديل</a></td>
                        <td><button class="btn btn-danger" onclick="deleteResume(<?= $resume['id'] ?>)">حذف</button></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
<script>
function deleteResume(id) {
    if (confirm("هل أنت متأكد من حذف السيرة؟")) {
        $.ajax({
            url: 'delete.php?id=' + id,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.error) {
                    alert('حدث خطأ: ' + response.msg);
                } else {
                    alert('تم الحذف بنجاح');
                    location.reload();
                }
            },
            error: function() {
                alert('حدث خطأ أثناء الاتصال بالخادم.');
            }
        });
    }
}
</script>
</body>
</html>
