This is a Resume Builder application form which you can generate a resume by just entering your details in a form and you will get a resume of a good template, it is built using PHP for backend, MySQL for database and for frontend HTML,CSS and JS/jQuery are used.

To use on loacal server.

First install xampp and copy the project file paste it into htdocs c/xampp/htdocs/Resume_Builder
Now open the xampp start apache and mysql server.
Open the admin pannel of mysql and create a database of name resume(or any name of your choice) and import the sql file(resumeBuilder.sql) present in the project root.
Now open the google chrome or any other browser and type in url section localhost/Resume_Builder.
You have to create a user first by registering on localhost/Resume_Builder/register.html.
After successfull registration you will be redirected to My Account page where all your resumes will be listed.
On that page you will get a button to Add A New Resume.