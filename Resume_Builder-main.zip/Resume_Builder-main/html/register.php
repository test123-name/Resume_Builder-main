<?php
session_start();
require_once '../php/db_connection.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (empty($username)) {
        $errors[] = "اسم المستخدم مطلوب.";
    }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "البريد الإلكتروني غير صالح.";
    }
    if (empty($password) || strlen($password) < 6) {
        $errors[] = "كلمة المرور يجب أن تكون 6 أحرف على الأقل.";
    }
    if ($password !== $password_confirm) {
        $errors[] = "تأكيد كلمة المرور غير مطابق.";
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM resume_users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = "البريد الإلكتروني مستخدم مسبقًا.";
        }
        $stmt->close();
    }

    if (empty($errors)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO resume_users (user_name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $password_hash);
        if ($stmt->execute()) {
            $success = "تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول.";
            $username = $email = '';
        } else {
            $errors[] = "حدث خطأ أثناء التسجيل، حاول مرة أخرى.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>تسجيل حساب جديد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <style>
      body {
        background-color: #0f0f23;
        color: #fff;
        font-family: 'Cairo', sans-serif;
      }
      .container {
        max-width: 400px;
        margin-top: 80px;
        background-color: #1a1a2e;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 10px #4e84f1;
      }
      a {
        color: #4e84f1;
      }
      a:hover {
        color: #74a9ff;
      }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mb-4 text-center">إنشاء حساب جديد</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?=htmlspecialchars($error)?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>

    <form method="POST" action="register.php" novalidate>
        <div class="mb-3">
            <label for="username" class="form-label">اسم المستخدم</label>
            <input type="text" id="username" name="username" class="form-control" required value="<?=htmlspecialchars($username ?? '')?>" />
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">البريد الإلكتروني</label>
            <input type="email" id="email" name="email" class="form-control" required value="<?=htmlspecialchars($email ?? '')?>" />
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">كلمة المرور</label>
            <input type="password" id="password" name="password" class="form-control" required minlength="6" />
        </div>
        <div class="mb-3">
            <label for="password_confirm" class="form-label">تأكيد كلمة المرور</label>
            <input type="password" id="password_confirm" name="password_confirm" class="form-control" required minlength="6" />
        </div>
        <button type="submit" class="btn btn-primary w-100">تسجيل</button>
    </form>

    <p class="mt-3 text-center">
        لديك حساب؟ <a href="login.php">تسجيل الدخول</a>
    </p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
