<?php
include_once('db_connection.php');
include_once('session.php');

$id = null;
$row = [];
$experiences = [];
$education = [];
$projects = [];
$certificates = [];

// منع التعديل إذا لم يكن المستخدم هو مالك السيرة
if (isset($_REQUEST['id'])) {
    $id = (int)$_REQUEST['id'];
}

if ($id) {
    // جلب بيانات السيرة الذاتية
    $sql = "SELECT * FROM resume_data WHERE id=$id";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $result->free_result();

        if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != $row['user_id']) {
            die("غير مصرح لك بتعديل هذه السيرة الذاتية.");
        }

        // جلب الخبرات
        $result = $conn->query("SELECT * FROM resume_experiences WHERE resume_id=$id");
        if ($result && $result->num_rows > 0) {
            $experiences = $result->fetch_all(MYSQLI_ASSOC);
            $result->free_result();
        }

        // جلب التعليم
        $result = $conn->query("SELECT * FROM resume_education WHERE resume_id=$id");
        if ($result && $result->num_rows > 0) {
            $education = $result->fetch_all(MYSQLI_ASSOC);
            $result->free_result();
        }

        // جلب المشاريع
        $result = $conn->query("SELECT * FROM resume_projects WHERE resume_id=$id");
        if ($result && $result->num_rows > 0) {
            $projects = $result->fetch_all(MYSQLI_ASSOC);
            $result->free_result();
        }

        // جلب الشهادات
        $result = $conn->query("SELECT * FROM resume_certificates WHERE resume_id=$id");
        if ($result && $result->num_rows > 0) {
            $certificates = $result->fetch_all(MYSQLI_ASSOC);
            $result->free_result();
        }
    } else {
        die("السيرة الذاتية غير موجودة.");
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>صفحتي الشخصية | Tawzeef</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
         body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #0b0c2a;
            color: #fff;
            direction: rtl;
            margin: 0;
            padding: 0;
        }

        .profile-container {
            display: flex;
            flex-direction: row;
            justify-content: center;
            padding: 40px;
            gap: 30px;
            flex-wrap: wrap;
        }

        .profile-card {
            background: linear-gradient(to bottom right, #4f00bc, #8f00ff);
            width: 300px;
            border-radius: 20px;
            text-align: center;
            padding: 30px 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.5);
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            background-color: #00aaff;
            border-radius: 50%;
            font-size: 48px;
            font-weight: bold;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 15px auto;
            color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }

        .profile-card h3 {
            margin: 10px 0 5px 0;
        }

        .profile-card p {
            margin-bottom: 20px;
            font-size: 14px;
        }

        .profile-card .btn {
            display: block;
            width: 100%;
            margin: 8px 0;
            font-weight: bold;
        }

        .info-panel {
            flex-grow: 1;
            background-color: #101032;
            padding: 30px;
            border-radius: 15px;
            min-width: 300px;
        }

        .info-title {
            font-size: 22px;
            margin-bottom: 20px;
            border-bottom: 2px solid #3b82f6;
            display: inline-block;
            padding-bottom: 5px;
        }

        .info-grid {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .info-box {
            background-color: #1e1e3f;
            flex: 1 1 250px;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }

        .info-box i {
            font-size: 24px;
            margin-bottom: 10px;
            display: block;
            color: #3b82f6;
        }

        @media (max-width: 768px) {
            .profile-container {
                flex-direction: column;
                align-items: center;
            }
        }
   :root {
    --background-dark: #0f0f23;
    --navbar-bg: #121227;
    --navbar-link-color: #ddd;
    --navbar-link-hover: #fff;
    --brand-color: #4e84f1;
    --hero-gradient-start: #6a11cb;
    --hero-gradient-end: #2575fc;
    --btn-start-bg: #e74c3c;
    --btn-start-bg-hover: #c0392b;
    --features-bg: #0d0d1a;
    --feature-box-bg: #1a1a2e;
    --feature-box-shadow: rgba(0,0,0,0.3);
    --feature-box-hover-shadow: rgba(78, 132, 241, 0.6);
    --footer-bg: #121227;
    --footer-text: #aaa;

    --card-dark: #1a1a2e;
    --box-shadow: 0 3px 8px rgba(0, 0, 0, 0.3);
    --text-white: #fff;
    --text-light: #d0d8ffcc;
    --accent-purple: #8a2be2;
    --border-color: #444766;
}

/* Body and General Styles */
body {
    background-color: var(--background-dark);
    color: var(--text-white);
    font-family: 'Cairo', sans-serif;
    margin: 0;
    padding: 0;
    line-height: 1.6;
}

/* Navbar */
.navbar {
    background-color: var(--navbar-bg);
    padding: 10px 20px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.5);
}

.navbar .nav-link {
    color: var(--navbar-link-color);
    transition: color 0.3s ease;
}

.navbar .nav-link:hover,
.navbar .nav-link:focus {
    color: var(--navbar-link-hover);
}

.navbar-brand {
    color: var(--brand-color);
    font-weight: 700;
    font-size: 1.5rem;
}

/* Navbar Left (Back button etc.) */
.navbar-left {
    display: flex;
    align-items: center;
    gap: 15px;
}

/* Hero Section */
.hero {
    background: linear-gradient(90deg, var(--hero-gradient-start) 0%, var(--hero-gradient-end) 100%);
    padding: 80px 20px;
    text-align: center;
    color: var(--text-white);
}

.hero h1 {
    font-size: 2.8rem;
    margin-bottom: 1rem;
    font-weight: 700;
    text-shadow: 0 2px 5px rgba(0,0,0,0.4);
}

.hero p {
    font-size: 1.2rem;
    max-width: 700px;
    margin: 0 auto 30px auto;
    color: var(--text-light);
}

.btn-start {
    background-color: var(--btn-start-bg);
    border: none;
    padding: 12px 30px;
    font-size: 1.1rem;
    font-weight: 600;
    border-radius: 5px;
    cursor: pointer;
    color: var(--text-white);
    transition: background-color 0.3s ease;
}

.btn-start:hover,
.btn-start:focus {
    background-color: var(--btn-start-bg-hover);
    outline: none;
}

/* Features Section */
.features {
    padding: 60px 20px;
    background-color: var(--features-bg);
    text-align: center;
}

.features h2 {
    color: var(--brand-color);
    margin-bottom: 2rem;
    font-weight: 700;
    font-size: 2rem;
}

.feature-box {
    background-color: var(--feature-box-bg);
    padding: 30px 25px;
    border-radius: 12px;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    box-shadow: var(--feature-box-shadow);
    margin: 15px;
}

.feature-box:hover,
.feature-box:focus-within {
    transform: translateY(-8px);
    box-shadow: 0 8px 20px var(--feature-box-hover-shadow);
}

.feature-box i {
    font-size: 2.8rem;
    margin-bottom: 15px;
    color: var(--accent-purple);
}

/* Footer */
footer {
    background-color: var(--footer-bg);
    padding: 20px 15px;
    text-align: center;
    color: var(--footer-text);
    margin-top: 40px;
    font-size: 0.9rem;
    user-select: none;
}

/* Form Page General Layout */
.container-form {
    display: flex;
    gap: 30px;
    padding: 20px;
    max-width: 1600px;
    margin: 20px auto;
    flex-wrap: wrap;
    align-items: flex-start;
}

/* Resume Preview Section (Left) */
.resume-preview {
    flex: 1;
    min-width: 380px;
    max-width: 500px;
    background-color: var(--card-dark);
    border-radius: 15px;
    padding: 30px;
    box-shadow: var(--box-shadow);
    display: flex;
    flex-direction: column;
    gap: 25px;
}

.preview-title {
    color: var(--text-white);
    font-size: 1.8em;
    margin-top: 0;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid var(--border-color);
    text-align: center;
}

.preview-section {
    padding-bottom: 20px;
    border-bottom: 1px dashed var(--border-color);
}

.preview-section:last-child {
    border-bottom: none;
}

.preview-heading {
    color: var(--accent-purple);
    font-size: 1.3em;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 10px;
    direction: rtl;
    justify-content: flex-end;
}

.preview-heading .icon {
    color: var(--text-light);
    font-size: 1.1em;
}

.preview-content {
    font-size: 1.1em;
    color: var(--text-light);
    margin: 5px 0;
    text-align: right;
}

/* Name in preview */
.name-placeholder {
    font-size: 1.6em;
    font-weight: bold;
    color: var(--text-white);
    text-align: center;
}

/* Education/Experience Items */
.education-item, .experience-item {
    margin-bottom: 15px;
}

.education-item p, .experience-item p {
    margin: 3px 0;
    font-size: 0.95em;
    color: var(--text-light);
}

.preview-degree, .preview-job-title {
    font-weight: bold;
    color: var(--text-white);
    font-size: 1.05em;
}

/* Skills List */
.skills-list {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    justify-content: flex-end;
}

.skill-tag {
    background-color: var(--accent-purple);
    color: var(--text-white);
    padding: 8px 15px;
    border-radius: 20px;
    font-size: 0.9em;
    white-space: nowrap;
}

/* Resume Form Area (Right) */
.resume-form-area {
    flex: 2;
    min-width: 500px;
    background-color: var(--card-dark);
    border-radius: 15px;
    padding: 30px;
    box-shadow: var(--box-shadow);
    display: flex;
    flex-direction: column;
}

.form-title {
    color: var(--text-white);
    font-size: 1.8em;
    margin-top: 0;
    margin-bottom: 25px;
    padding-bottom: 15px;
    border-bottom: 1px solid var(--border-color);
    text-align: right;
}

.form-section {
    margin-bottom: 30px;
}

.form-section h3 {
    color: var(--text-light);
    font-size: 1.5em;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 1px solid var(--border-color);
    text-align: right;
}

.form-group {
    margin-bottom: 15px;
    text-align: right;
}

.form-group label {
    display: block;
    color: var(--text-light);
    font-size: 1em;
    margin-bottom: 8px;
    font-weight: bold;
}

.form-group input[type="text"],
.form-group input[type="email"],
.form-group input[type="tel"],
.form-group input[type="number"],
.form-group input[type="date"],
.form-group textarea {
    width: 100%;
    padding: 12px 15px;
    background-color: rgba(255, 255, 255, 0.08);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    color: var(--text-white);
    font-size: 1em;
    box-sizing: border-box;
    transition: border-color 0.3s ease,
background-color 0.3s ease;
}

.form-group input[type="text"]:focus,
.form-group input[type="email"]:focus,
.form-group input[type="tel"]:focus,
.form-group input[type="number"]:focus,
.form-group input[type="date"]:focus,
.form-group textarea:focus {
outline: none;
background-color: rgba(78, 132, 241, 0.15);
border-color: var(--brand-color);
box-shadow: 0 0 6px var(--brand-color);
}

.form-group textarea {
min-height: 100px;
resize: vertical;
}

/* Buttons */
.btn-primary {
background-color: var(--brand-color);
color: var(--text-white);
border: none;
padding: 12px 25px;
font-size: 1.1em;
border-radius: 8px;
cursor: pointer;
font-weight: 700;
transition: background-color 0.3s ease;
align-self: flex-start;
}

.btn-primary:hover,
.btn-primary:focus {
background-color: #3869d4;
outline: none;
}

/* Responsive adjustments */
@media (max-width: 992px) {
.container-form {
flex-direction: column;
padding: 10px;
}
.resume-preview,
.resume-form-area {
max-width: 100%;
min-width: auto;
}
}

@media (max-width: 576px) {
.hero h1 {
font-size: 2rem;
}
.hero p {
font-size: 1rem;
}
.btn-start {
padding: 10px 20px;
font-size: 1rem;
}
}
@media (max-width: 992px) {
    .container-form {
        flex-direction: column; /* يصبح عمودي (عمود) */
        padding: 10px;
    }
    .resume-preview,
    .resume-form-area {
        max-width: 100%;    /* عرض 100% */
        min-width: auto;    /* لا يوجد حد أدنى */
    }
}

    </style>
</head>

<body>
      <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="index.php">توظيف | Tawzeef</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </nav>
    <div class="container">
        <h1 class="text-center mb-3">منشئ السيرة الذاتية</h1>
        <h3 class="text-center mb-4">املأ بياناتك الشخصية والمهنية</h3>

        <form action="../php/formCode.php" method="post" enctype="multipart/form-data" autocomplete="off">

            <input type="hidden" name="id" value="<?= htmlspecialchars($id) ?>" />

            <div class="row g-4">

                <!-- البيانات الشخصية -->
                <div class="col-md-6">
                    <h4 class="text-center mb-3">المعلومات الشخصية</h4>

                    <div class="mb-3">
                        <label for="name" class="form-label">الاسم الكامل</label>
                        <input type="text" id="name" name="name" required class="form-control" placeholder="أدخل اسمك الكامل" value="<?= htmlspecialchars($row['name'] ?? '') ?>" />
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">البريد الإلكتروني</label>
                        <input type="email" id="email" name="email" required class="form-control" placeholder="أدخل بريدك الإلكتروني" value="<?= htmlspecialchars($row['email'] ?? '') ?>" />
                        <div class="form-text">لن نشارك بريدك الإلكتروني مع أي جهة.</div>
                    </div>

                    <div class="mb-3">
                        <label for="contact" class="form-label">رقم الهاتف</label>
                        <input type="tel" id="contact" name="contact" required class="form-control" placeholder="أدخل رقم هاتفك" value="<?= htmlspecialchars($row['phone'] ?? '') ?>" />
                    </div>

                    <div class="mb-3">
                        <label for="address" class="form-label">العنوان</label>
                        <textarea id="address" name="address" required class="form-control" placeholder="أدخل عنوانك"><?= htmlspecialchars($row['address'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="language" class="form-label">اللغات</label>
                        <input type="text" id="language" name="language" class="form-control" placeholder="أدخل اللغات مفصولة بفواصل" value="<?= htmlspecialchars($row['language'] ?? '') ?>" />
                        <div class="form-text">مثال: العربية, الإنجليزية, الفرنسية</div>
                    </div>

                    <div class="mb-3">
                        <label for="interest" class="form-label">الهوايات</label>
                        <input type="text" id="interest" name="interest" class="form-control" placeholder="أدخل الهوايات مفصولة بفواصل" value="<?= htmlspecialchars($row['interest'] ?? '') ?>" />
                        <div class="form-text">مثال: القراءة, السفر, الرياضة</div>
                    </div>

                    <div class="mb-3">
                        <label for="skill" class="form-label">المهارات</label>
                        <input type="text" id="skill" name="skill" class="form-control" placeholder="أدخل المهارات مفصولة بفواصل" value="<?= htmlspecialchars($row['skill'] ?? '') ?>" />
                        <div class="form-text">مثال: PHP, JavaScript, تصميم جرافيك</div>
                    </div>

                    <h5 class="mt-4 mb-3">روابط مهمة</h5>

                    <div class="mb-3">
                        <label for="linkedin" class="form-label">لينكدإن</label>
                        <input type="url" id="linkedin" name="linkedin" class="form-control" placeholder="رابط حساب لينكدإن" value="<?= htmlspecialchars($row['linkedin'] ?? '') ?>" />
                    </div>

                    <div class="mb-3">
                        <label for="github" class="form-label">جيت هب</label>
                        <input type="url" id="github" name="github" class="form-control" placeholder="رابط حساب جيت هب" value="<?= htmlspecialchars($row['github'] ?? '') ?>" />
                    </div>

                    <div class="mb-3">
                        <label for="instagram" class="form-label">إنستغرام</label>
                        <input type="url" id="instagram" name="instagram" class="form-control" placeholder="رابط حساب إنستغرام" value="<?= htmlspecialchars($row['instagram'] ?? '') ?>" />
                    </div>

                </div>

                <!-- المعلومات المهنية -->
                <div class="col-md-6">
                    <h4 class="text-center mb-3">المعلومات المهنية</h4>

                    <div class="mb-3">
                        <label for="objective" class="form-label">الهدف المهني</label>
                        <textarea id="objective" name="objective" required class="form-control" placeholder="اكتب هدفك المهني"><?= htmlspecialchars($row['career_objective'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="title" class="form-label">المسمى الوظيفي</label>
                        <input type="text" id="title" name="title" required class="form-control" placeholder="المسمى الوظيفي" value="<?= htmlspecialchars($row['title'] ?? '') ?>" />
                    </div>

                    <div class="mb-3">
                        <label class="form-label">الصورة الشخصية الحالية</label><br />
                        <?php if (!empty($row['profile_pic']) && file_exists("../uploads/" . $row['profile_pic'])): ?>
                            <img id="profile_current_img" src="../uploads/<?= htmlspecialchars($row['profile_pic']) ?>" alt="الصورة الشخصية الحالية" />
                        <?php else: ?>
                            <p>لا توجد صورة شخصية مرفوعة.</p>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="profile_pic" class="form-label">تحديث الصورة الشخصية</label>
                        <input type="file" id="profile_pic" name="profile_pic" accept="image/*" class="form-control" />
                        <small class="form-text text-muted">اختياري - تحميل صورة جديدة لاستبدال الحالية</small>
                    </div>

                    <!-- خبرة العمل -->
                    <h5 class="mt-4">الخبرات العملية</h5>
                    <div id="experience">
                        <?php if (empty($experiences)) : ?>
                            <div class="experience_field border rounded p-3 mb-3 position-relative">
                                <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                <label>المسمى الوظيفي</label>
                                <input type="text" name="job_title[]" class="form-control mb-2" placeholder="المسمى الوظيفي" required />
                                <label>اسم الشركة</label>
                                <input type="text" name="company_name[]" class="form-control mb-2" placeholder="اسم الشركة" required />
                                <label>الفترة</label>
                                <input type="text" name="duration[]" class="form-control mb-2" placeholder="مثال: 2019-2021" required />
                                <label>الوصف</label>
                                <textarea name="job_description[]" class="form-control mb-2" placeholder="وصف الخبرة" required></textarea>
                            </div>
                        <?php else : ?>
                            <?php foreach ($experiences as $exp) : ?>
                                <div class="experience_field border rounded p-3 mb-3 position-relative">
                                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                    <label>المسمى الوظيفي</label>
                                    <input type="text" name="job_title[]" class="form-control mb-2" placeholder="المسمى الوظيفي" required value="<?= htmlspecialchars($exp['job_title']) ?>" />
                                    <label>اسم الشركة</label>
                                    <input type="text" name="company_name[]" class="form-control mb-2" placeholder="اسم الشركة" required value="<?= htmlspecialchars($exp['company_name']) ?>" />
                                    <label>الفترة</label>
                                    <input type="text" name="duration[]" class="form-control mb-2" placeholder="مثال: 2019-2021" required value="<?= htmlspecialchars($exp['duration']) ?>" />
                                    <label>الوصف</label>
                                    <textarea name="job_description[]" class="form-control mb-2" placeholder="وصف الخبرة" required><?= htmlspecialchars($exp['job_description']) ?></textarea>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm mb-3" id="add_experience">إضافة خبرة</button>

                    <!-- التعليم -->
                    <h5 class="mt-4">المؤهلات التعليمية</h5>
                    <div id="education">
                        <?php if (empty($education)) : ?>
                            <div class="education_field border rounded p-3 mb-3 position-relative">
                                <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                <label>اسم المؤسسة التعليمية</label>
                                <input type="text" name="school_name[]" class="form-control mb-2" placeholder="اسم المؤسسة" required />
                                <label>التخصص</label>
                                <input type="text" name="specialization[]" class="form-control mb-2" placeholder="التخصص" required />
                                <label>الفترة</label>
                                <input type="text" name="education_duration[]" class="form-control mb-2" placeholder="مثال: 2015-2019" required />
                            </div>
                        <?php else : ?>
                            <?php foreach ($education as $edu) : ?>
                                <div class="education_field border rounded p-3 mb-3 position-relative">
                                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                    <label>اسم المؤسسة التعليمية</label>
                                    <input type="text" name="school_name[]" class="form-control mb-2" placeholder="اسم المؤسسة" required value="<?= htmlspecialchars($edu['school_name']) ?>" />
                                    <label>التخصص</label>
                                    <input type="text" name="specialization[]" class="form-control mb-2" placeholder="التخصص" required value="<?= htmlspecialchars($edu['specialization']) ?>" />
                                    <label>الفترة</label>
                                    <input type="text" name="education_duration[]" class="form-control mb-2" placeholder="مثال: 2015-2019" required value="<?= htmlspecialchars($edu['education_duration']) ?>" />
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm mb-3" id="add_education">إضافة تعليم</button>

                    <!-- المشاريع -->
                    <h5 class="mt-4">المشاريع الشخصية</h5>
                    <div id="projects">
                        <?php if (empty($projects)) : ?>
                            <div class="project_field border rounded p-3 mb-3 position-relative">
                                <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                <label>اسم المشروع</label>
                                <input type="text" name="project_name[]" class="form-control mb-2" placeholder="اسم المشروع" required />
                                <label>الوصف</label>
                                <textarea name="project_desc[]" class="form-control mb-2" placeholder="وصف المشروع" required></textarea>
                            </div>
                        <?php else : ?>
                            <?php foreach ($projects as $prj) : ?>
                                <div class="project_field border rounded p-3 mb-3 position-relative">
                                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                    <label>اسم المشروع</label>
                                    <input type="text" name="project_name[]" class="form-control mb-2" placeholder="اسم المشروع" required value="<?= htmlspecialchars($prj['project_name']) ?>" />
                                    <label>الوصف</label>
                                    <textarea name="project_desc[]" class="form-control mb-2" placeholder="وصف المشروع" required><?= htmlspecialchars($prj['project_desc']) ?></textarea>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm mb-3" id="add_project">إضافة مشروع</button>

                    <!-- الشهادات -->
                    <h5 class="mt-4">الشهادات</h5>
                    <div id="certificates">
                        <?php if (empty($certificates)) : ?>
                            <div class="certificate_field border rounded p-3 mb-3 position-relative">
                                <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                <label>اسم الشهادة</label>
                                <input type="text" name="certificate_name[]" class="form-control mb-2" placeholder="اسم الشهادة" required />
                                <label>جهة الإصدار</label>
                                <input type="text" name="certificate_issuer[]" class="form-control mb-2" placeholder="جهة الإصدار" required />
                                <label>تاريخ الإصدار</label>
                                <input type="date" name="certificate_date[]" class="form-control mb-2" required />
                            </div>
                        <?php else : ?>
                            <?php foreach ($certificates as $cert) : ?>
                                <div class="certificate_field border rounded p-3 mb-3 position-relative">
                                    <button type="button" class="btn btn-danger btn-sm position-absolute top-0 start-0 remove_field" title="حذف">×</button>
                                    <label>اسم الشهادة</label>
                                    <input type="text" name="certificate_name[]" class="form-control mb-2" placeholder="اسم الشهادة" required value="<?= htmlspecialchars($cert['certificate_name']) ?>" />
                                    <label>جهة الإصدار</label>
                                    <input type="text" name="certificate_issuer[]" class="form-control mb-2" placeholder="جهة الإصدار" required value="<?= htmlspecialchars($cert['certificate_issuer']) ?>" />
                                    <label>تاريخ الإصدار</label>
                                    <input type="date" name="certificate_date[]" class="form-control mb-2" required value="<?= htmlspecialchars($cert['certificate_date']) ?>" />
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <button type="button" class="btn btn-primary btn-sm mb-3" id="add_certificate">إضافة شهادة</button>

                </div>
            </div>

            <div class="text-center mt-4 mb-4">
                <button type="submit" class="btn btn-success btn-lg px-5">حفظ السيرة الذاتية</button>
            </div>

        </form>
    </div>

    <script>
        // دالة لإضافة عنصر جديد داخل container
        function addField(containerId, fieldHtml) {
            const container = document.getElementById(containerId);
            const div = document.createElement('div');
            div.innerHTML = fieldHtml;
            container.appendChild(div.firstElementChild);
        }

        // دالة إنشاء زر حذف
        function createRemoveBtn() {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn-danger btn-sm position-absolute top-0 start-0 remove_field';
            btn.title = 'حذف';
            btn.textContent = '×';
            btn.onclick = function () {
                btn.parentElement.remove();
            };
            return btn;
        }

        // أزرار الإضافة والديناميكية للخبرة
        document.getElementById('add_experience').addEventListener('click', function () {
            const container = document.getElementById('experience');
            const div = document.createElement('div');
            div.className = 'experience_field border rounded p-3 mb-3 position-relative';

            div.innerHTML = `
                <label>المسمى الوظيفي</label>
                <input type="text" name="job_title[]" class="form-control mb-2" placeholder="المسمى الوظيفي" required />
                <label>اسم الشركة</label>
                <input type="text" name="company_name[]" class="form-control mb-2" placeholder="اسم الشركة" required />
                <label>الفترة</label>
                <input type="text" name="duration[]" class="form-control mb-2" placeholder="مثال: 2019-2021" required />
                <label>الوصف</label>
                <textarea name="job_description[]" class="form-control mb-2" placeholder="وصف الخبرة" required></textarea>
            `;
            div.appendChild(createRemoveBtn());
            container.appendChild(div);
        });

        // أزرار الإضافة للدراسة
        document.getElementById('add_education').addEventListener('click', function () {
            const container = document.getElementById('education');
            const div = document.createElement('div');
            div.className = 'education_field border rounded p-3 mb-3 position-relative';

            div.innerHTML = `
                <label>اسم المؤسسة التعليمية</label>
                <input type="text" name="school_name[]" class="form-control mb-2" placeholder="اسم المؤسسة" required />
                <label>التخصص</label>
                <input type="text" name="specialization[]" class="form-control mb-2" placeholder="التخصص" required />
                <label>الفترة</label>
                <input type="text" name="education_duration[]" class="form-control mb-2" placeholder="مثال: 2015-2019" required />
            `;
            div.appendChild(createRemoveBtn());
            container.appendChild(div);
        });

        // أزرار الإضافة للمشاريع
        document.getElementById('add_project').addEventListener('click', function () {
            const container = document.getElementById('projects');
            const div = document.createElement('div');
            div.className = 'project_field border rounded p-3 mb-3 position-relative';

            div.innerHTML = `
                <label>اسم المشروع</label>
                <input type="text" name="project_name[]" class="form-control mb-2" placeholder="اسم المشروع" required />
                <label>الوصف</label>
                <textarea name="project_desc[]" class="form-control mb-2" placeholder="وصف المشروع" required></textarea>
            `;
            div.appendChild(createRemoveBtn());
            container.appendChild(div);
        });

        // أزرار الإضافة للشهادات
        document.getElementById('add_certificate').addEventListener('click', function () {
            const container = document.getElementById('certificates');
            const div = document.createElement('div');
            div.className = 'certificate_field border rounded p-3 mb-3 position-relative';

            div.innerHTML = `
                <label>اسم الشهادة</label>
                <input type="text" name="certificate_name[]" class="form-control mb-2" placeholder="اسم الشهادة" required />
                <label>جهة الإصدار</label>
                <input type="text" name="certificate_issuer[]" class="form-control mb-2" placeholder="جهة الإصدار" required />
                <label>تاريخ الإصدار</label>
                <input type="date" name="certificate_date[]" class="form-control mb-2" required />
            `;
            div.appendChild(createRemoveBtn());
            container.appendChild(div);
        });

        // إضافة حدث حذف لأي زر حذف موجود حالياً أو مستقبلاً
        document.body.addEventListener('click', function (e) {
            if (e.target.classList.contains('remove_field')) {
                e.target.parentElement.remove();
            }
        });
    </script>
</body>

</html>
