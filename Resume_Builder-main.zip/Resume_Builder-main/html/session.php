<?php
// session.php

// تأكد أن الجلسة لم تبدأ مسبقًا قبل استدعاء session_start()
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
