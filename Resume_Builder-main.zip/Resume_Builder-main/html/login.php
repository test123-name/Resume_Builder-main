<?php
session_start();

// الاتصال بقاعدة البيانات
require_once '../php/db_connection.php'; // تأكد أن هذا هو المسار الصحيح حسب هيكل المجلدات

$errors = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "البريد الإلكتروني غير صالح.";
    }
    if (empty($password)) {
        $errors[] = "كلمة المرور مطلوبة.";
    }

    if (empty($errors)) {
        // استخدم استعلام آمن مع كلمة مرور مشفرة
        $stmt = $conn->prepare("SELECT id, user_name, password FROM resume_users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if ($user) {
            // تحقق من كلمة المرور
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['user_name'];

                header("Location: myAccount.php");
                exit;
            } else {
                $errors[] = "كلمة المرور غير صحيحة.";
            }
        } else {
            $errors[] = "الحساب غير موجود.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل الدخول</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #0f0f23;
            color: #fff;
            font-family: 'Cairo', sans-serif;
        }
        .container {
            max-width: 400px;
            margin-top: 80px;
            background-color: #1a1a2e;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 0 10px #4e84f1;
        }
        a {
            color: #4e84f1;
        }
        a:hover {
            color: #74a9ff;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mb-4 text-center">تسجيل الدخول</h2>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php" novalidate>
        <div class="mb-3">
            <label for="email" class="form-label">البريد الإلكتروني</label>
            <input type="email" id="email" name="email" class="form-control" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">كلمة المرور</label>
            <input type="password" id="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">دخول</button>
    </form>

    <p class="mt-3 text-center">
        ليس لديك حساب؟ <a href="register.php">إنشاء حساب جديد</a>
    </p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
