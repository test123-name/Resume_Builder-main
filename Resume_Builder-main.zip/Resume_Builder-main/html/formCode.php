<?php
include_once('db_connection.php');
include_once('session.php');
include_once('redirect.php');

$userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

function cleanInput($conn, $input) {
    return $conn->real_escape_string(trim($input));
}

// استلام البيانات مع التنظيف (يمكن تعديل أو إضافة تحقق هنا حسب الحاجة)
$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : null;
$name = isset($_REQUEST['name']) ? cleanInput($conn, $_REQUEST['name']) : null;
$email = isset($_REQUEST['email']) ? cleanInput($conn, $_REQUEST['email']) : null;
$phone = isset($_REQUEST['contact']) ? cleanInput($conn, $_REQUEST['contact']) : null;
$address = isset($_REQUEST['address']) ? cleanInput($conn, $_REQUEST['address']) : null;
$linkedin = isset($_REQUEST['linkedin']) ? cleanInput($conn, $_REQUEST['linkedin']) : null;
$github = isset($_REQUEST['github']) ? cleanInput($conn, $_REQUEST['github']) : null;
$instagram = isset($_REQUEST['instagram']) ? cleanInput($conn, $_REQUEST['instagram']) : null;
$objective = isset($_REQUEST['objective']) ? cleanInput($conn, $_REQUEST['objective']) : null;
$language = isset($_REQUEST['language']) ? cleanInput($conn, $_REQUEST['language']) : null;
$interest = isset($_REQUEST['interest']) ? cleanInput($conn, $_REQUEST['interest']) : null;
$skill = isset($_REQUEST['skill']) ? cleanInput($conn, $_REQUEST['skill']) : null;
$title = isset($_REQUEST['title']) ? cleanInput($conn, $_REQUEST['title']) : null;

// البيانات المصفوفية (خبرات، تعليم، مشاريع، شهادات)
$exprId = isset($_REQUEST['expr_id']) ? $_REQUEST['expr_id'] : [];
$educId = isset($_REQUEST['educ_id']) ? $_REQUEST['educ_id'] : [];
$projId = isset($_REQUEST['proj_id']) ? $_REQUEST['proj_id'] : [];
$certId = isset($_REQUEST['cert_id']) ? $_REQUEST['cert_id'] : [];

$exprPositions = isset($_REQUEST['expr_position']) ? $_REQUEST['expr_position'] : [];
$exprCompanies = isset($_REQUEST['expr_company']) ? $_REQUEST['expr_company'] : [];
$exprDurations = isset($_REQUEST['expr_duration']) ? $_REQUEST['expr_duration'] : [];

$educCourses = isset($_REQUEST['educ_course']) ? $_REQUEST['educ_course'] : [];
$educColleges = isset($_REQUEST['educ_college']) ? $_REQUEST['educ_college'] : [];
$educPercentages = isset($_REQUEST['educ_percentage']) ? $_REQUEST['educ_percentage'] : [];
$educDurations = isset($_REQUEST['educ_duration']) ? $_REQUEST['educ_duration'] : [];

$projTitles = isset($_REQUEST['proj_title']) ? $_REQUEST['proj_title'] : [];
$projDescriptions = isset($_REQUEST['proj_desc']) ? $_REQUEST['proj_desc'] : [];

$certTitles = isset($_REQUEST['cert_title']) ? $_REQUEST['cert_title'] : [];
$certDescriptions = isset($_REQUEST['cert_desc']) ? $_REQUEST['cert_desc'] : [];
$certDates = isset($_REQUEST['cert_date']) ? $_REQUEST['cert_date'] : [];

// رفع الصورة
$imageUploaded = false;
$targetDir = "../assets/img/";
$fileName = "";
if (isset($_FILES["profile_pic"]) && $_FILES["profile_pic"]["error"] === UPLOAD_ERR_OK) {
    $fileName = basename($_FILES["profile_pic"]["name"]);
    $targetFilePath = $targetDir . $fileName;
    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    if (in_array(strtolower($fileType), $allowTypes)) {
        if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFilePath)) {
            $imageUploaded = true;
        } else {
            die("حدث خطأ أثناء رفع الملف.");
        }
    } else {
        die("نوع الملف غير مسموح به.");
    }
}

// دالة لإعداد وتنفيد الاستعلامات المحضرة وإرجاع الـ stmt
function prepareAndExecute($conn, $sql, $types = "", $params = []) {
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("خطأ في تحضير الاستعلام: " . $conn->error);
    }
    if (!empty($types) && !empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    if (!$stmt->execute()) {
        die("خطأ في تنفيذ الاستعلام: " . $stmt->error);
    }
    return $stmt;
}

// إدخال أو تحديث البيانات الأساسية للسيرة الذاتية
if ($id) {
    $sql = "UPDATE resume_data SET name=?, email=?, phone=?, address=?, linkedin=?, github=?, instagram=?, career_objective=?, language=?, interest=?, skill=?, title=? WHERE id=?";
    prepareAndExecute($conn, $sql, "ssssssssssssi", [$name, $email, $phone, $address, $linkedin, $github, $instagram, $objective, $language, $interest, $skill, $title, $id]);
    $lastId = $id;
} else {
    $sql = "INSERT INTO resume_data (name, email, phone, address, linkedin, github, instagram, career_objective, language, interest, skill, title, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    prepareAndExecute($conn, $sql, "sssssssssssii", [$name, $email, $phone, $address, $linkedin, $github, $instagram, $objective, $language, $interest, $skill, $title, $userId ?? null]);
    $lastId = $conn->insert_id;
}

// تحديث الصورة في حال تم رفعها
if ($imageUploaded && $fileName !== "") {
    $sql = "UPDATE resume_data SET profile_pic=? WHERE id=?";
    prepareAndExecute($conn, $sql, "si", [$fileName, $lastId]);
}

// دوال لإدارة البيانات المرتبطة (خبرات، تعليم، مشاريع، شهادات)
function processEntries($conn, $table, $resumeId, $entries, $columns) {
    foreach ($entries as $entry) {
        // تأكد وجود ID أو أنه جديد
        $hasId = isset($entry['id']) && !empty($entry['id']);
        $emptyEntry = true;
        // نتحقق إذا كان الحقل الرئيسي (عادة أول عمود) غير فارغ
        $mainColumn = $columns[0];
        if (!empty($entry[$mainColumn])) {
            $emptyEntry = false;
        }

        if ($hasId && !$emptyEntry) {
            // تحديث
            $setPart = implode("=?, ", $columns) . "=?";
            $sql = "UPDATE $table SET $setPart WHERE id=?";
            $types = str_repeat("s", count($columns)) . "i";
            $params = [];
            foreach ($columns as $col) {
                $params[] = $entry[$col];
            }
            $params[] = $entry['id'];
            prepareAndExecute($conn, $sql, $types, $params);
        } elseif ($hasId && $emptyEntry) {
            // حذف
            $sql = "DELETE FROM $table WHERE id=?";
            prepareAndExecute($conn, $sql, "i", [$entry['id']]);
        } elseif (!$hasId && !$emptyEntry) {
            // إدخال جديد
            $colsStr = implode(", ", array_merge(['resume_id'], $columns));
            $placeholders = implode(", ", array_fill(0, count($columns) + 1, "?"));
            $sql = "INSERT INTO $table ($colsStr) VALUES ($placeholders)";
            $types = "i" . str_repeat("s", count($columns));
            $params = array_merge([$resumeId], array_map(function($col) use ($entry) {
                return $entry[$col];
            }, $columns));
            prepareAndExecute($conn, $sql, $types, $params);
        }
    }
}

// تجهيز مصفوفات البيانات للمعالجة
$experiences = [];
$countExp = max(count($exprPositions), count($exprCompanies), count($exprDurations), count($exprId));
for ($i = 0; $i < $countExp; $i++) {
    $experiences[] = [
        'id' => $exprId[$i] ?? null,
        'position' => cleanInput($conn, $exprPositions[$i] ?? ''),
        'company' => cleanInput($conn, $exprCompanies[$i] ?? ''),
        'duration' => cleanInput($conn, $exprDurations[$i] ?? ''),
    ];
}

$education = [];
$countEduc = max(count($educCourses), count($educColleges), count($educPercentages), count($educDurations), count($educId));
for ($i = 0; $i < $countEduc; $i++) {
    $education[] = [
        'id' => $educId[$i] ?? null,
        'course' => cleanInput($conn, $educCourses[$i] ?? ''),
        'college' => cleanInput($conn, $educColleges[$i] ?? ''),
        'percentage' => cleanInput($conn, $educPercentages[$i] ?? ''),
        'duration' => cleanInput($conn, $educDurations[$i] ?? ''),
    ];
}

$projects = [];
$countProj = max(count($projTitles), count($projDescriptions), count($projId));
for ($i = 0; $i < $countProj; $i++) {
    $projects[] = [
        'id' => $projId[$i] ?? null,
        'title' => cleanInput($conn, $projTitles[$i] ?? ''),
        'description' => cleanInput($conn, $projDescriptions[$i] ?? ''),
    ];
}

$certifications = [];
$countCert = max(count($certTitles), count($certDescriptions), count($certDates), count($certId));
for ($i = 0; $i < $countCert; $i++) {
    $certifications[] = [
        'id' => $certId[$i] ?? null,
        'title' => cleanInput($conn, $certTitles[$i] ?? ''),
        'description' => cleanInput($conn, $certDescriptions[$i] ?? ''),
        'date' => cleanInput($conn, $certDates[$i] ?? ''),
    ];
}

// معالجة كل قسم
processEntries($conn, 'resume_experiences', $lastId, $experiences, ['position', 'company', 'duration']);
processEntries($conn, 'resume_education', $lastId, $education, ['course', 'college', 'percentage', 'duration']);
processEntries($conn, 'resume_projects', $lastId, $projects, ['title', 'description']);
processEntries($conn, 'resume_certificates', $lastId, $certifications, ['title', 'description', 'date']);

// تحويل إلى صفحة عرض السيرة الذاتية
Redirect('resumeTemplate.php?id=' . $lastId, false);

?>
