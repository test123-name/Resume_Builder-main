<?php
session_start();
include_once('db_connection.php'); // تأكد من صحة المسار

// تحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];

// جلب بيانات المستخدم
$stmt = $conn->prepare("SELECT user_name, email FROM resume_users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("المستخدم غير موجود");
}

$user = $result->fetch_assoc();
$stmt->close();

$fullName = htmlspecialchars($user['user_name']);
$email = htmlspecialchars($user['email']);
$avatarLetter = mb_substr($fullName, 0, 1, "UTF-8");
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>صفحتي الشخصية | Tawzeef</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #0b0c2a;
            color: #fff;
            direction: rtl;
            margin: 0;
            padding: 0;
        }

        .profile-container {
            display: flex;
            flex-direction: row;
            justify-content: center;
            padding: 40px;
            gap: 30px;
            flex-wrap: wrap;
        }

        .profile-card {
            background: linear-gradient(to bottom right, #4f00bc, #8f00ff);
            width: 300px;
            border-radius: 20px;
            text-align: center;
            padding: 30px 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.5);
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            background-color: #00aaff;
            border-radius: 50%;
            font-size: 48px;
            font-weight: bold;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0 auto 15px auto;
            color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }

        .profile-card h3 {
            margin: 10px 0 5px 0;
        }

        .profile-card p {
            margin-bottom: 20px;
            font-size: 14px;
        }

        .profile-card .btn {
            display: block;
            width: 100%;
            margin: 8px 0;
            font-weight: bold;
        }

        .info-panel {
            flex-grow: 1;
            background-color: #101032;
            padding: 30px;
            border-radius: 15px;
            min-width: 300px;
        }

        .info-title {
            font-size: 22px;
            margin-bottom: 20px;
            border-bottom: 2px solid #3b82f6;
            display: inline-block;
            padding-bottom: 5px;
        }

        .info-grid {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .info-box {
            background-color: #1e1e3f;
            flex: 1 1 250px;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }

        .info-box i {
            font-size: 24px;
            margin-bottom: 10px;
            display: block;
            color: #3b82f6;
        }

        @media (max-width: 768px) {
            .profile-container {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="index.php">توظيف | Tawzeef</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </nav>
<div class="profile-container">
    <!-- البطاقة الجانبية -->
    <div class="profile-card">
        <div class="profile-avatar"><?= $avatarLetter ?></div>
        <h3><?= $fullName ?></h3>
        <p><?= $email ?></p>
        <a href="#" class="btn btn-primary"><i class="fas fa-user"></i> بياناتي</a>
        <a href="resumeForm.php" class="btn btn-light text-dark"><i class="fas fa-file-alt"></i> السير الذاتية</a>
        <a href="#" class="btn btn-light text-dark"><i class="fas fa-paper-plane"></i> التقديمات</a>
        <a href="#" class="btn btn-light text-dark"><i class="fas fa-cog"></i> الإعدادات</a>
        <a href="logoutCode.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> تسجيل الخروج</a>
    </div>

    <!-- معلومات المستخدم -->
    <div class="info-panel">
        <div class="info-title">بياناتي الشخصية</div>
        <div class="info-grid">
            <div class="info-box">
                <i class="fas fa-user"></i>
                <strong>الاسم الكامل</strong><br>
                <?= $fullName ?>
            </div>
            <div class="info-box">
                <i class="fas fa-envelope"></i>
                <strong>البريد الإلكتروني</strong><br>
                <?= $email ?>
            </div>
            <div class="info-box">
                <i class="fas fa-calendar-alt"></i>
                <strong>تاريخ الميلاد</strong><br>
                1990-01-01
            </div>
            <div class="info-box">
                <i class="fas fa-map-marker-alt"></i>
                <strong>المدينة</strong><br>
                الرياض
            </div>
        </div>
    </div>
</div>

</body>
</html>
