<?php
include_once('db_connection.php');
include_once('session.php');

// الحصول على معرف السيرة الذاتية من الرابط
$id = null;
if (isset($_REQUEST['id'])) {
    $id = $_REQUEST['id'];
} else {
    echo "السيرة الذاتية غير موجودة";
    die;
}

// جلب بيانات السيرة الذاتية الأساسية
$sql = "SELECT * FROM resume_data WHERE id=$id";
$result = $conn->query($sql);

if (!$result->num_rows > 0) {
    echo "السيرة الذاتية غير موجودة";
    die;
}
$row = $result->fetch_all(MYSQLI_ASSOC)[0];
// تحرير الذاكرة بعد جلب النتائج
$result->free_result();

// جلب خبرات العمل من جدول الخبرات
$sql = "SELECT * FROM resume_experiences WHERE resume_id=$id";
$result = $conn->query($sql);
$experiences = [];
if ($result->num_rows > 0) {
    $experiences = $result->fetch_all(MYSQLI_ASSOC);
    $result->free_result();
}

// جلب المؤهلات التعليمية
$sql = "SELECT * FROM resume_education WHERE resume_id=$id";
$result = $conn->query($sql);
$education = [];
if ($result->num_rows > 0) {
    $education = $result->fetch_all(MYSQLI_ASSOC);
    $result->free_result();
}

// جلب المشاريع الشخصية
$sql = "SELECT * FROM resume_projects WHERE resume_id=$id";
$result = $conn->query($sql);
$projects = [];
if ($result->num_rows > 0) {
    $projects = $result->fetch_all(MYSQLI_ASSOC);
    $result->free_result();
}

// جلب الشهادات
$sql = "SELECT * FROM resume_certificates WHERE resume_id=$id";
$result = $conn->query($sql);
$certificates = [];
if ($result->num_rows > 0) {
    $certificates = $result->fetch_all(MYSQLI_ASSOC);
    $result->free_result();
}

// تحديد صورة الملف الشخصي أو استخدام صورة افتراضية
$profilePic = "../assets/img/";
if ($row['profile_pic']) {
    $profilePic .= $row['profile_pic'];
} else {
    $profilePic .= 'default_profile.png';
}
?>

<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>نموذج السيرة الذاتية | منشئ السيرة الذاتية</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- CSS الخاص بالقالب -->
    <link rel="stylesheet" href="../css/template_style.css" />
    <!-- CSS خاص بالطباعة -->
    <link rel="stylesheet" href="../css/print.css" />
    <!-- Font Awesome للرموز -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
</head>

<body class="A4">
    <div id="resume_container" class="container">

        <div class="row">
            <!-- القسم الأيسر: المعلومات الشخصية -->
            <div class="col-md-4 pb-4" id="personal_info">
                <!-- صورة الملف الشخصي -->
                <div class="container img_container mt-2">
                    <img src="<?= $profilePic; ?>" alt="صورة الملف الشخصي" class="img-fluid profile_img" />
                </div>

                <!-- المعلومات العامة -->
                <div class="container mt-4" id="general_info">

                    <p><i class="fas fa-at icons"></i> <?= htmlspecialchars($row['email']) ?></p>
                    <p><i class="fas fa-phone icons"></i> <?= htmlspecialchars($row['phone']) ?></p>
                    <p><i class="fas fa-map-marker-alt icons"></i> <?= htmlspecialchars($row['address']) ?></p>

                    <!-- روابط مهمة -->
                    <div class="links" id="git">
                        <i class="fab fa-git-square icons"></i>
                        <a href="<?= htmlspecialchars($row['github']) ?>" target="_blank"><?= htmlspecialchars($row['github']) ?></a>
                    </div>
                    <div class="links" id="linkedin">
                        <i class="fab fa-linkedin icons"></i>
                        <a href="<?= htmlspecialchars($row['linkedin']) ?>" target="_blank"><?= htmlspecialchars($row['linkedin']) ?></a>
                    </div>
                    <div class="links" id="instagram">
                        <i class="fab fa-instagram-square icons"></i>
                        <a href="<?= htmlspecialchars($row['instagram']) ?>" target="_blank"><?= htmlspecialchars($row['instagram']) ?></a>
                    </div>
                </div>

                <!-- المهارات -->
                <div class="container mt-5" id="skill">
                    <h4>المهارات</h4>
                    <hr />
                    <?php
                    $skills = explode(',', $row['skill']);
                    foreach ($skills as $skill) { ?>
                        <span class="blocks mt-2"><?= htmlspecialchars(trim($skill)) ?></span>
                    <?php } ?>
                </div>

                <!-- اللغات -->
                <div class="container mt-5" id="language">
                    <h4>اللغات</h4>
                    <hr />
                    <?php
                    $languages = explode(',', $row['language']);
                    foreach ($languages as $language) { ?>
                        <span class="blocks"><?= htmlspecialchars(trim($language)) ?></span>
                    <?php } ?>
                </div>

                <!-- الاهتمامات -->
                <div class="container mt-5" id="interest">
                    <h4>الاهتمامات</h4>
                    <hr />
                    <?php
                    $interests = explode(',', $row['interest']);
                    foreach ($interests as $interest) { ?>
                        <span class="blocks"><?= htmlspecialchars(trim($interest)) ?></span>
                    <?php } ?>
                </div>
            </div>

            <!-- القسم الأيمن: المعلومات المهنية -->
            <div class="col-md-8" id="professional_info">

                <div id="header" class="text-center mb-4">
                    <h1 id="name"><?= htmlspecialchars($row['name']) ?></h1>
                    <h4 id="title" class="text-muted"><?= htmlspecialchars($row['title']) ?></h4>
                    <p id="objective"><?= htmlspecialchars($row['career_objective']) ?></p>
                </div>

                <div id="content">
                    <!-- الخبرات العملية -->
                    <div class="container" id="experience">
                        <h3>الخبرات العملية</h3>
                        <hr />
                        <?php foreach ($experiences as $expr) { ?>
                            <div class="experience_field field_blocks">
                                <strong class="expr_title title fields"><?= htmlspecialchars($expr['position']) ?></strong>
                                <div class="expr_company fields"><?= htmlspecialchars($expr['company']) ?></div>
                                <div class="expr_duration duration fields text-muted"><?= htmlspecialchars($expr['duration']) ?></div>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- التعليم -->
                    <div class="container mt-4" id="education">
                        <h3>المؤهلات التعليمية</h3>
                        <hr />
                        <?php foreach ($education as $educ) { ?>
                            <div class="education_field field_blocks">
                                <strong class="educ_course title fields"><?= htmlspecialchars($educ['course']) ?></strong>
                                <span class="educ_prcnt fields"><?= htmlspecialchars($educ['percentage']) ?></span>
                                <div class="educ_college fields"><?= htmlspecialchars($educ['college']) ?></div>
                                <div class="educ_duration duration fields text-muted"><?= htmlspecialchars($educ['duration']) ?></div>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- المشاريع -->
                    <div class="container mt-4" id="project">
                        <h3>المشاريع الشخصية</h3>
                        <hr />
                        <?php foreach ($projects as $proj) { ?>
                            <div class="project_field field_blocks">
                                <strong class="proj_title title fields"><?= htmlspecialchars($proj['title']) ?></strong>
                                <p class="proj_desc fields"><?= htmlspecialchars($proj['description']) ?></p>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- الشهادات -->
                    <div class="container mt-4" id="certificate">
                        <h3>الشهادات</h3>
                        <hr />
                        <?php foreach ($certificates as $cert) { ?>
                            <div class="certificate_field field_blocks">
                                <strong class="cert_title title fields"><?= htmlspecialchars($cert['title']) ?></strong>
                                <p class="cert_desc fieldss"><?= htmlspecialchars($cert['description']) ?></p>
                                <span class="cert_date duration fields text-muted"><?= htmlspecialchars($cert['date']) ?></span>
                            </div>
                        <?php } ?>
                    </div>

                    <!-- إقرار -->
                    <div class="container mt-4" id="declaration">
                        <h3>الإقرار</h3>
                        <hr />
                        <p class="fields">أقر بأن جميع المعلومات الواردة أعلاه صحيحة ودقيقة حسب أفضل علمي.</p>
                    </div>
                </div>

            </div>
        </div>

    </div>

    <!-- زر تحميل أو طباعة السيرة -->
    <div class="container text-center my-5">
        <button class="btn btn-primary" id="download" onclick="printPageArea('resume_container')">تحميل السيرة الذاتية</button>
    </div>

    <!-- مكتبة رموز الخطوط -->
    <script src="https://kit.fontawesome.com/5c3f7a5924.js" crossorigin="anonymous"></script>

    <script>
        // دالة لطباعة جزء معين من الصفحة
        function printPageArea(areaID) {
            var originalContent = document.body.innerHTML;
            var printContent = document.getElementById(areaID).innerHTML;
            document.body.innerHTML = printContent;
            window.print();
            document.body.innerHTML = originalContent;
        }
    </script>
</body>

</html>
